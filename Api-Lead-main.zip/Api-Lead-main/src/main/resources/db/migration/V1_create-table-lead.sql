CREATE TABLE tblead (
    telefone VARCHAR(100) NOT NULL,
    PRIMARY KEY (id)
)

CREATE TABLE tbgenero (
    id BIGINT NOT NULL auto_increment,
    nome VARCHAR(100) NOT NULL,
)