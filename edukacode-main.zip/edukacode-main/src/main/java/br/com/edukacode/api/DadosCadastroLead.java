package br.com.edukacode.api;

public record DadosCadastroLead(String nome, String email, String telefone) {}
